package com.example.exaspotify;

import com.example.exaspotify.Clases.Connexion;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import javax.swing.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class crearPlayController {

    @FXML
    private Button btnPlay;
    @FXML
    private TextField crearP;

    public void crearPlaylist() throws SQLException {
        Connexion conectar = new Connexion();
        Connection ahora = conectar.getConnection();
        String query = "insert into playlist (titulo,fecha_creacion,usuario_id) values ('"+crearP.getText()+"',curdate(),'1');";
        Statement statement = ahora.createStatement();
        statement.execute(query);
        JOptionPane salida = new JOptionPane();
        JOptionPane.showMessageDialog(salida,"Se ha creado correctamente la nueva playlist");

    }






}
