package com.example.exaspotify.Controladores;

import com.example.exaspotify.Clases.Playlist;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class playlistController {
    @FXML
    private Label nombrePlay;
    public void setData (Playlist playlist) {
        nombrePlay.setText(playlist.getNombre());
    }
}

