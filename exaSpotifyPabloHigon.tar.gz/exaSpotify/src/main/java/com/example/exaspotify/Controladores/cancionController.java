package com.example.exaspotify.Controladores;

import com.example.exaspotify.Clases.Cancion;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class cancionController{

    @FXML
    private Label cantante;
    @FXML
    private Label titulo;
        public void setData(Cancion cancion){
        titulo.setText(cancion.getTitulo());
        cantante.setText(cancion.getCantante());

        }

    }

