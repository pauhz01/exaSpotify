package com.example.exaspotify.Controladores;

import com.example.exaspotify.Clases.CancionPlaylist;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class labelPlayController {
@FXML
private Label nombreLabel;
public void setData(CancionPlaylist cancionPlaylist){
    nombreLabel.setText(cancionPlaylist.getNombre());
}
}
