package com.example.exaspotify.Clases;

public class CancionPlaylist {
    private String nombre;
    private String artista;

    private int favor;

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public int getFavor() {
        return favor;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public String getArtista() {
        return artista;
    }

    public void setFavor(int favor) {
        this.favor = favor;
    }
}
