package com.example.exaspotify;

import com.example.exaspotify.Clases.CancionPlaylist;
import com.example.exaspotify.Controladores.cancionController;
import com.example.exaspotify.Controladores.labelPlayController;
import com.example.exaspotify.Controladores.playlistController;
import com.example.exaspotify.Clases.Cancion;
import com.example.exaspotify.Clases.Connexion;
import com.example.exaspotify.Clases.Playlist;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;
import java.sql.*;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.swing.*;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
public class spotifyController  {
    @FXML
    private Button salir;
    @FXML
    private VBox playFavs;
    @FXML
    public Label userName;
    @FXML
    private HBox recientes;
    @FXML
    private Button meGusta;
    @FXML
    private Label nombrePlay;
    @FXML
    private HBox favoritas;
    @FXML
    private Button btnLogin;
    @FXML
    public TextField uInicio ;
    @FXML
    private PasswordField pInicio;
    @FXML
    private Button registrate;
    @FXML
    private Label cancionCambio;
    @FXML
    private Label artistaCambio;

    List<Playlist> favsC;
    List<CancionPlaylist> canC;
    List<Cancion> favoritasC;

    String usu;
    FXMLLoader principal;
    spotifyController spotifyController;
    public void isesion (ActionEvent event){
        Connexion conectar = new Connexion();
        Connection ahora = conectar.getConnection();
        usu = uInicio.getText();

        String query = "SELECT username,password from usuario WHERE username= '"+usu+"' AND password ='"+pInicio.getText()+"'";
        try {
            Statement statement = ahora.createStatement();
            try (ResultSet queryOut = statement.executeQuery(query)){
                if (queryOut.next()) {
                    abrePrincipal();

                    Stage myStage = (Stage) this.btnLogin.getScene().getWindow();
                    myStage.close();
                }  else {
                    JFrame error = new JFrame();
                    JOptionPane.showMessageDialog(error,"Nombre de usuario o contraseña incorrecta");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void registrate (ActionEvent event) throws IOException {
        abreRegistro();
        Stage myStage = (Stage) this.registrate.getScene().getWindow();
        myStage.close();
    }
    public void abrePrincipal() throws IOException{
        principal = new FXMLLoader(getClass().getResource("spotify.fxml"));
        Stage stage = new Stage();
        Parent root = principal.load();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Spotify");
        spotifyController = principal.getController();
        spotifyController.userName.setText(usu);
        spotifyController.cancionesFavoritas();
        spotifyController.playlistFavs();
        stage.show();
    }
    public void abreInicio () throws IOException{
        FXMLLoader inicio = new FXMLLoader(getClass().getResource("inicioSesion.fxml"));
        Parent root = inicio.load();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Inicio de sesion");
        stage.show();
    }
    public void abreRegistro() throws IOException{
        FXMLLoader registro = new FXMLLoader(getClass().getResource("registro.fxml"));
        Parent root = registro.load();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Bienvenido al mundo de la música");
        stage.show();
    }
    public void abreCrearPlaylist() throws IOException{
        FXMLLoader registro = new FXMLLoader(getClass().getResource("crearPlaylist.fxml"));
        Parent root = registro.load();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Crear a tu ritmo");
        stage.show();

    }
    public  void cancionesPlaylist()  {
        try {
            canC = new ArrayList<>(getCanC());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        try {
            for (CancionPlaylist cancionPlaylist : canC) {
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation((getClass().getResource("labelPlaylist.fxml")));
                VBox vBox = fxmlLoader.load();
                labelPlayController prueba = fxmlLoader.getController();
                prueba.setData(cancionPlaylist);

                recientes.getChildren().add(vBox);
                vBox.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        cancionCambio.setText(cancionPlaylist.getNombre());
                        artistaCambio.setText(cancionPlaylist.getArtista());
                    }
                });
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
    public  void cancionesFavoritas()  {
        try {
            favoritasC = new ArrayList<>(getFavoritasC());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        try {
            for (Cancion cancion : favoritasC) {
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation((getClass().getResource("cancion.fxml")));

                VBox vBox = fxmlLoader.load();
                cancionController prueba = fxmlLoader.getController();
                prueba.setData(cancion);
                favoritas.getChildren().add(vBox);
                vBox.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        cancionCambio.setText(cancion.getTitulo());
                        artistaCambio.setText(cancion.getCantante());
                    }
                });

            }
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
    public  void playlistFavs()  {
        try {
           favsC  = new ArrayList<>(getPlayFavsC());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        try {
            for (Playlist playlist : favsC) {
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation((getClass().getResource("playlistfavs.fxml")));
                VBox vBox = fxmlLoader.load();
                playlistController prueba = fxmlLoader.getController();
                prueba.setData(playlist);
                playFavs.getChildren().add(vBox);

                vBox.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        cancionesPlaylist();
                        nombrePlay.setText(playlist.getNombre());

                    }
                });
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Cancion> getFavoritasC () throws SQLException {
        List <Cancion> ls = new ArrayList<>();
        Connexion conectar = new Connexion();
        Connection ahora = conectar.getConnection();

        String queryCancion ="SELECT t1.titulo FROM cancion t1 inner JOIN album t2 ON t1.album_id = t2.id inner JOIN artista t3 ON t2.artista_id = t3.id inner join guarda_cancion t4 on t4.cancion_id =  t1.id inner join usuario t5 on  t4.usuario_id = t5.id and t5.username ='antonio'";
        String queryArtista = "SELECT t3.nombre FROM cancion t1 inner JOIN album t2 ON t1.album_id = t2.id inner JOIN artista t3 ON t2.artista_id = t3.id inner join guarda_cancion t4 on t4.cancion_id =  t1.id inner join usuario t5 on  t4.usuario_id = t5.id and t5.username = 'antonio'";


        Statement statementCancion =ahora.createStatement();
        Statement statementArtista =ahora.createStatement();

        ResultSet titulo = statementCancion.executeQuery(queryCancion);
        ResultSet artista = statementArtista.executeQuery(queryArtista);
        int favo = 1;

        while (titulo.next() && artista.next()){
            Cancion cancion = new Cancion();
            cancion.setTitulo(titulo.getString(1));
            cancion.setCantante(artista.getString(1));
            ls.add(cancion);
        }
        return ls;
    }
    public List<Playlist> getPlayFavsC () throws SQLException {
        List <Playlist> pp = new ArrayList<>();
        Connexion conectar = new Connexion();
        Connection ahora = conectar.getConnection();

        String queryPlay ="SELECT t3.titulo FROM spotify.usuario t1 inner join sigue_playlist t2 on t2.usuario_id = t1.id and t1.id = '1' inner join playlist t3 on t2.playlist_id = t3.id";
        Statement statementCancion =ahora.createStatement();

        ResultSet nombrePlay = statementCancion.executeQuery(queryPlay);

        while (nombrePlay.next()){
            Playlist playlist = new Playlist();
            playlist.setNombre(nombrePlay.getString(1));
            pp.add(playlist);
        }
        return pp;
    }
    public List<CancionPlaylist> getCanC () throws SQLException {
        List<CancionPlaylist> bb = new ArrayList<>();
        Connexion conectar = new Connexion();
        Connection ahora = conectar.getConnection();
        String queryPlay ="select t1.titulo,t3.nombre from cancion t1 inner join album t2 on t2.id = t1.album_id inner join artista t3 on t3.id = t2.artista_id inner join anyade_cancion_playlist t4 on t1.id = t4.cancion_id inner join playlist t5 on t5.id = t4.playlist_id and t5.titulo = '"+nombrePlay.getText()+"'";
        Statement statementCancion =ahora.createStatement();

        ResultSet cancionPlay = statementCancion.executeQuery(queryPlay);

        while (cancionPlay.next()){
            CancionPlaylist cancionPlaylist = new CancionPlaylist();
            cancionPlaylist.setNombre(cancionPlay.getString(1));
            bb.add(cancionPlaylist);
        }
        return bb;
    }

    public  void iniciando () throws IOException {
        abreInicio();
        Stage myStage = (Stage) this.salir.getScene().getWindow();
        myStage.close();
    }
    public  void meGusta() throws IOException, SQLException {
        Connexion conectar = new Connexion();
        Connection ahora = conectar.getConnection();
        String query = "insert into prueba (cancion,titulo) values('"+cancionCambio.getText()+"','"+artistaCambio.getText()+"')";
        Statement statement = ahora.createStatement();
        statement.execute(query);
    }
    public  void  refresh() {
        try {
            abrePrincipal();
            Stage myStage = (Stage) this.salir.getScene().getWindow();
            myStage.close();
            } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}


