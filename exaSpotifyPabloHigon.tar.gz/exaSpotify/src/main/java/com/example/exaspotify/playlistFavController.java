package com.example.exaspotify;

import com.example.exaspotify.Controladores.labelPlayController;
import com.example.exaspotify.Clases.CancionPlaylist;
import com.example.exaspotify.Clases.Connexion;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.awt.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class playlistFavController extends spotifyController {

    @FXML
    private Label nombre;
    @FXML
    private VBox canciondePlaylist;


    List<CancionPlaylist> canC;

    spotifyController spotifyController;



}
