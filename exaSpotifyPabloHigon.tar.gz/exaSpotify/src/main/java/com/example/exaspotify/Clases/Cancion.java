package com.example.exaspotify.Clases;

public class Cancion {
    private  String titulo;
    private String cantante;

    private int favo;

    public String getCantante() {
        return cantante;
    }

    public int getFavo() {
        return favo;
    }

    public void setFavo(int favo) {
        this.favo = favo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setCantante(String cantante) {
        this.cantante = cantante;
    }



    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

}
