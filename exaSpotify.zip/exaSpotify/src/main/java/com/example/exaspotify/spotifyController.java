package com.example.exaspotify;

import java.sql.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.sql.Connection;

public class spotifyController {
    @FXML
    private Button btnLogin;
    @FXML
    private Label userName;
    @FXML
    private TextField uInicio;
    @FXML
    private PasswordField pInicio;
    public void boton (ActionEvent event){

        Connexion conectar = new Connexion();
        Connection ahora = conectar.getConnection();
        String query = "SELECT es_compartida from activa LIMIT 1";
        try {
            Statement  statement = ahora.createStatement();
            ResultSet queryOut = statement.executeQuery(query);
            while (queryOut.next()){
                userName.setText(queryOut.getString("es_compartida"));
            }
        } catch (Exception e){
            e.printStackTrace();
        }

    }
    public void isesion (ActionEvent event){
        Connexion conectar = new Connexion();
        Connection ahora = conectar.getConnection();
        String query = "SELECT username,password from usuario WHERE username= '"+ uInicio.getText() + "' + AND password ='"+ pInicio.getText() +"'";
        try {
            Statement  statement = ahora.createStatement();
            ResultSet queryOut = statement.executeQuery(query);
            while (queryOut.next()) {
                System.out.printf("Hola");
                if (queryOut.getInt(1) == 1){
                    System.out.printf("Bienvendio" + uInicio);
                } else {
                    System.out.printf("Lavate el cuello");
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }

    }}

